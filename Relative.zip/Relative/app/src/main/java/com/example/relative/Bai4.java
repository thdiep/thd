package com.example.relative;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Bai4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai4);
    }
}